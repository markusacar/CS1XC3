/**
 * @file course.c
 * @author Markus Acar (acarm@mcmaster.ca)
 * @brief Defines course functions 
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>



/**
 * @brief Adds a given student to a course's students.
 * 
 * @param course Course that student is enroll in.
 * @param student The student that enroll.
 */

void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    // Must allocate memory if this is the first student.
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    // If it is not first student, reallocate space to fit with new student.
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Prints all course information.
 * 
 * @param course Course to print.
 */
void print_course(Course* course)
{ printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  // loops through array of enrolled students and the information for all students in the course.
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Returns student with the highest average of a given course. 
 * 
 * @param course The course to get the top student from.
 * @return Student* 
 */
Student* top_student(Course* course)
{ if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }
  // returns the top student with highest average
  return student;
}

/**
 * @brief Returns an array of all passing students the given course.
 * 
 * @param course Course to find passing students.
 * @param total_passing Total number of passing students.
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  // calculates number of passing students with average.
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  // if they are passing the course then add students to the array.
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }
  *total_passing = count;
  return passing;
}