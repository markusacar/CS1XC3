/**
 * @file student.h
 * @author Markus Acar (acarm@mcmaster.ca)
 * @brief 
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief Student type stores information about a student.
 * 
 */
typedef struct _student
{
    char first_name[50]; /**< First name of the student */
    char last_name[50];  /**< Last name of the student */
    char id[11];         /**< The student's id */
    double *grades;      /**< Array of the students grades. */
    int num_grades;      /**< Total grades of student */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student *generate_random_student(int grades);